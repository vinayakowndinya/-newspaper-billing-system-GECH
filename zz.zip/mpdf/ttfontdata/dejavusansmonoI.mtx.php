<?php
$name='DejaVuSansMono-Oblique';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 69,
  'FontBBox' => '[-403 -375 746 1028]',
  'ItalicAngle' => -11,
  'StemV' => 87,
  'MissingWidth' => 602,
);
$up=-63;
$ut=44;
$ttffile='/var/www/html/vtucr/mpdf/ttfonts/DejaVuSansMono-Oblique.ttf';
$TTCfontID='0';
$originalsize=230244;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansmonoI';
$panose=' 0 0 2 b 6 9 3 3 4 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>