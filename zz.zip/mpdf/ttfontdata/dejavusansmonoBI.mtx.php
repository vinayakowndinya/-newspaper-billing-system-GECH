<?php
$name='DejaVuSansMono-BoldOblique';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 262213,
  'FontBBox' => '[-425 -394 808 1053]',
  'ItalicAngle' => -11,
  'StemV' => 165,
  'MissingWidth' => 602,
);
$up=-63;
$ut=44;
$ttffile='/var/www/html/vtucr/mpdf/ttfonts/DejaVuSansMono-BoldOblique.ttf';
$TTCfontID='0';
$originalsize=224160;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansmonoBI';
$panose=' 0 0 2 b 7 9 3 3 4 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>